print("Hello world! fuck you! they gonna need a wrecking ball to take me out of here . They gonna need national guards or swat team because i ain't going anywhere.")
